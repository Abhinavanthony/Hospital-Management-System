import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Invoice } from "../common/invoice";
import { Observable } from "rxjs";

@Injectable({
  providedIn: 'root'
})
export class Invoicesearch {
  private baseURL = "http://localhost:9090/api/v1/invoice";

  constructor(private httpClient: HttpClient) { }

  createInvoice(employee: Invoice): Observable<Object> {
    return this.httpClient.post(this.baseURL, employee);
  }

  read(id: any): Observable<any> {
    console.log(id);
    return this.httpClient.get(`${this.baseURL}/${id}`);
  }
}
