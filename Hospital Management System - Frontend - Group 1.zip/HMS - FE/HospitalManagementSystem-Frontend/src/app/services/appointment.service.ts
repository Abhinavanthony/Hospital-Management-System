import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';
import { Appointment } from '../common/appointment';

@Injectable({
  providedIn: 'root'
})
export class AppointmentService {
    private baseUrl = 'http://localhost:9090/api/v1/appointment';// Update the base URL according to your backend API endpoint

  constructor(private http: HttpClient) { }

  createAppointment(appointment: Appointment): Observable<Appointment> {
    const url = `${this.baseUrl}`;
    return this.http.post<Appointment>(url, appointment);
  }

  getAppointmentslist(): Observable<Appointment[]> {
    const url = `${this.baseUrl}`;
    return this.http.get<Appointment[]>(url).pipe(
      tap(data => console.log('Appointments Response:', data)) // Log the response
    );
  }

  approveAppointment(appointmentId: number): Observable<Appointment> {
    const url =`${this.baseUrl}/${appointmentId}/approve`;
    return this.http.put<Appointment>(url, {});
  }

  deleteAppointment(id: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/${id}`);
  }

  markAsAttended(id: number): Observable<Appointment> {
    const body = {}; // You can add any request payload here if needed
    return this.http.put<Appointment>(`${this.baseUrl}/${id}`, body);
  }
rejectAppointment(appointmentId: number): Observable<Appointment> {
    const url = `${this.baseUrl}/${appointmentId}/reject`;
    return this.http.put<Appointment>(url, {});


  }
}