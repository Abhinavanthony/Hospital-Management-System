export class Patient {
    id: string;
    fname: string;
    lname: string;
    email: string;
    dob:string;
    phone:number;
    gender:string;
    disease: string;
    room: string;
    address:string;
    status: string;
}