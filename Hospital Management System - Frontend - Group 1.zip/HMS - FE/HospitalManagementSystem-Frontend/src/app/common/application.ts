export class Application{

    id: string;
    name: string;
    age: string;
    qual: string;
    number: string
}
