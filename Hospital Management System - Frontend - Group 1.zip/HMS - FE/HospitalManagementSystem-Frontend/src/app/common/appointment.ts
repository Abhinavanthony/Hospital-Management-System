export class Appointment {
  id?: number;
  pname: string;
  symptoms: string;
  number: string;
  status?: string;
  
  constructor(pname: string, symptoms: string, number: string, id?: number, status?: string, attended?: boolean) {
      this.id = id;
      this.pname = pname;
      this.symptoms = symptoms;
      this.number = number;
      this.status = status || 'Pending';
      
  }
}