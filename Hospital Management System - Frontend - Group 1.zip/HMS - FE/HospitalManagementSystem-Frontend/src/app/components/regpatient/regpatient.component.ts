import { Component, OnInit } from '@angular/core';
import { Patient } from 'src/app/common/patient';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { PatientService } from 'src/app/services/patient.service';

@Component({
  selector: 'app-regpatient',
  templateUrl: './regpatient.component.html',
  styleUrls: ['./regpatient.component.css']
})
export class RegpatientComponent implements OnInit {

  role: string = localStorage.getItem('role');
  patient: Patient = new Patient();
  patientService: PatientService;
  errorMessage: string = '';

  constructor(private router: Router, private httpClient: HttpClient) { }

  ngOnInit(): void {
  }

  saveApplication() {
    if (this.checkForEmptyFields()) {
      this.errorMessage = 'Please fill in all the required fields.';
      alert('Please fill in all the required fields.');
      return;
    }

    const url = 'http://localhost:9090/api/v1/patient';
    this.httpClient.post(url, this.patient)
      .subscribe(
        (result) => {
          this.ngOnInit(); // reload the table
          alert('Patient Registered Successfully');
        },
        (error) => {
          this.errorMessage = 'An error occurred while registering the patient. Please try again later.';
          console.log(error);
        }
      );
  }

  checkForEmptyFields(): boolean {
    return (
      !this.patient.fname ||
      !this.patient.lname ||
      !this.patient.email ||
      !this.patient.dob ||
      !this.patient.phone ||
      !this.patient.gender ||
      !this.patient.disease ||
      !this.patient.room ||
      !this.patient.address
    );
  }

  onSubmit() {
    this.errorMessage = '';
    this.saveApplication();
  }
}