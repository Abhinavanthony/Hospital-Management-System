import { Component, OnInit } from '@angular/core';
import { Application } from 'src/app/common/application';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { RegdoctorService } from 'src/app/services/regdoctor.service'

@Component({
  selector: 'app-regdoc',
  templateUrl: './regdoc.component.html',
  styleUrls: ['./regdoc.component.css']
})
export class RegdocComponent implements OnInit {

  application: Application = new Application();
  regdoctorService: RegdoctorService;
  errorMessage: string = '';

  constructor(private router: Router, private httpClient: HttpClient) { }

  ngOnInit(): void {
  }

  saveApplication() {
    if (this.checkForEmptyFields()) {
      this.errorMessage = 'Please fill in all the required fields.';
      alert('Please fill in all the required fields.');
      return;
    }

    const url = 'http://localhost:9090/api/v1/application';
    this.httpClient.post(url, this.application)
      .subscribe(
        (result) => {
          this.ngOnInit(); // reload the table
          alert('Form Submitted Successfully');
          this.router.navigate(['/home']);
        },
        error => console.log(error)
      );
  }

  checkForEmptyFields(): boolean {
    if (
      !this.application.name ||
      !this.application.age ||
      !this.application.qual ||
      !this.application.number
    ) {
      return true;
    }
    return false;
  }

  onSubmit() {
    this.errorMessage = '';
    this.saveApplication();
  }
}