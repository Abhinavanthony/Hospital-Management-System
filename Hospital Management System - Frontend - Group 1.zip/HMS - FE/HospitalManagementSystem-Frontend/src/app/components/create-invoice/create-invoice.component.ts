import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Invoice } from 'src/app/common/invoice';
import { Invoicesearch } from 'src/app/services/invoice.service';


@Component({
  selector: 'app-create-invoice',
  templateUrl: './create-invoice.component.html',
  styleUrls: ['./create-invoice.component.css']
})
export class CreateInvoiceComponent implements OnInit {

    invoice: Invoice = new Invoice();
    constructor(private invoiceService: Invoicesearch,
      private router: Router) { }

  ngOnInit(): void {
  }

  saveInvoice(){
    this.invoiceService.createInvoice(this.invoice).subscribe( data =>{
      console.log(data);
      this.goToInvoiceList();
    },
    error => console.log(error));
  }
  
  goToInvoiceList(){
    this.router.navigate(['/invoice']);
  }
  
  onSubmit(){
    console.log(this.invoice);
    this.saveInvoice();
  }
}
