import { Component, OnInit } from '@angular/core';
import { Appointment } from 'src/app/common/appointment';
import { AppointmentService } from 'src/app/services/appointment.service';

@Component({
  selector: 'app-appointment-list',
  templateUrl: './appointment-list.component.html',
  styleUrls: ['./appointment-list.component.css']
})
export class AppointmentListComponent implements OnInit {
  appointments: Appointment[];
  role: string = 'Admin'; // Assuming 'Admin' role for this example

  constructor(private appointmentService: AppointmentService) {}

  ngOnInit(): void {
    this.getAppointments();
  }

  private getAppointments() {
    this.appointmentService.getAppointmentslist().subscribe(
      data => {
        this.appointments = data;
      }
    );
  }

  approve(appointment: Appointment) {
    this.appointmentService.approveAppointment(appointment.id).subscribe(
      response => {
        if (response && response.status === 'Approved') {
          appointment.status = 'Approved';
          alert('Appointment successfully approved! and message sent to patient');
        } else {
          alert('Failed to approve appointment. Please try again later.');
        }
      },
      error => {
        console.error('Error approving appointment:', error);
        alert('Failed to approve appointment. Please try again later.');
      }
    );
  }


  deleteAppointment(id: number) {
    this.appointmentService.deleteAppointment(id).subscribe(data => {
      console.log(data);
      this.getAppointments();
    });
  }

  attended(appointmentId: number) {
    this.appointmentService.deleteAppointment(appointmentId).subscribe(
      data => {
        console.log(data);
        alert('Patient Attended!');
        this.getAppointments();
      },
      error => {
        console.error('Error marking appointment as attended:', error);
        alert('Failed to mark appointment as attended. Please try again later.');
      }
    );
  }

  reject(appointment: Appointment) {
    this.appointmentService.rejectAppointment(appointment.id).subscribe(
      response => {
        if (response && response.status === 'Rejected') {
          appointment.status = 'Rejected';
          alert('Appointment successfully rejected!');
        } else {
          alert('Failed to reject appointment. Please try again later.');
        }
      },
      error => {
        console.error('Error rejecting appointment:', error);
        alert('Failed to reject appointment. Please try again later.');
      }
    );
  }
}