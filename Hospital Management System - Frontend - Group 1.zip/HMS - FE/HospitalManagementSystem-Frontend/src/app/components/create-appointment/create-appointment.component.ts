import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { Appointment } from 'src/app/common/appointment';
import { AppointmentService } from 'src/app/services/appointment.service';

@Component({
  selector: 'app-create-appointment',
  templateUrl: './create-appointment.component.html',
  styleUrls: ['./create-appointment.component.css']
})
export class CreateAppointmentComponent {
  appointment: Appointment = { pname: '', symptoms: '', number: '' };

  constructor(private router: Router, private appointmentService: AppointmentService) { }

  saveAppointment(): void {
    if (this.appointment.pname.trim() === '') {
      alert('Patient Name is required.');
      return;
    }
    this.appointmentService.createAppointment(this.appointment).subscribe(
      (result: Appointment) => {
        console.log('Appointment Saved:', result);
        alert('Appointment Scheduled Successfully');
        this.router.navigate(['/dashboard']);
      },
      error => {
        console.error('Error saving appointment:', error);
        alert('Error scheduling appointment. Please try again.');
      }
    );
  }

  onSubmit(): void {
    console.log('Submitted Appointment:', this.appointment);
    this.saveAppointment();
  }
}
