package com.ehospital.entity;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="appointment")
public class Appointment {
@Id
private int id;
@GeneratedValue(strategy = GenerationType.IDENTITY)
@Column(name="pname")
private String pname;
@Column(name="symptoms")
private String symptoms;
 @Column(name="mobilenumber")
 private String number;
 @Column(name = "status")
 private String status; // Added status field
 
 public Appointment() {
     this.status = "Pending";
 }
 

public int getId() {
return id;
}
public void setId(int id) {
this.id = id;
}
public String getPname() {
return pname;
}
public void setPname(String pname) {
this.pname = pname;
}
public String getSymptoms() {
return symptoms;
}
public void setSymptoms(String symptoms) {
this.symptoms = symptoms;
}
public String getNumber() {
 return number;
 }
 public void setNumber(String number) {
 this.number = number;
 }
public String getStatus() {
	// TODO Auto-generated method stubr
	return status;
}
public void setStatus(String status) {
	// TODO Auto-generated method stub
	this.status= status;
}
}