package com.ehospital.service;

import com.ehospital.dao.AppointmentRepository;
import com.ehospital.entity.Appointment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityNotFoundException;
import java.util.List;
import java.util.Optional;

@Service
public class AppointmentService {

    private final AppointmentRepository appointmentRepository;

    @Autowired
    public AppointmentService(AppointmentRepository appointmentRepository) {
        this.appointmentRepository = appointmentRepository;
    }

    public Optional<Appointment> getAppointmentById(int id) {
        return appointmentRepository.findById(id);
    }

    public Appointment createAppointment(Appointment appointment) {
        return appointmentRepository.save(appointment);
    }

    @Transactional
    public void updateStatus(int id, String status) {
        try {
            Appointment appointment = appointmentRepository.findById(id)
                    .orElseThrow(() -> new EntityNotFoundException("Appointment not found with id: " + id));
            appointment.setStatus(status);
        } catch (Exception e) {
            // Log the exception for debugging
            e.printStackTrace();
            // Handle the exception or rethrow it based on your application's requirements.
        }
    }

    public void deleteAppointment(int id) {
        appointmentRepository.deleteById(id);
    }

    public boolean approveAppointment(int id) {
        Optional<Appointment> optionalAppointment = appointmentRepository.findById(id);
        if (optionalAppointment.isPresent() && "Pending".equals(optionalAppointment.get().getStatus())) {
            Appointment appointment = optionalAppointment.get();
            appointment.setStatus("Approved");
            appointmentRepository.save(appointment);
            return true; // Approval successful
        }
        return false; // Appointment not found or already approved/rejected
    }

    public List<Appointment> getAllAppointments() {
        return appointmentRepository.findAll();
    }
}