package com.ehospital.controller;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.management.AttributeNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ehospital.dao.AppointmentRepository;
import com.ehospital.entity.Appointment;

// imports...

@RestController
@CrossOrigin("http://localhost:4200")
@RequestMapping("/api/v1/")
public class AppointmentController {

    @Autowired
    private AppointmentRepository appointmentRepository;

    // Get all appointments
    @GetMapping("/appointment")
    public List<Appointment> getAllAppointments() {
        return appointmentRepository.findAll();
    }

    // Create a new appointment
   // @PostMapping("/appointment")
   // public Appointment createAppointment(@RequestBody Appointment appointment) {
      //  return appointmentRepository.save(appointment);
    //}
    @PostMapping("/appointment")
    public ResponseEntity<Appointment> createAppointment(@RequestBody Appointment appointment) {
        try {
            Appointment createdAppointment = appointmentRepository.save(appointment);
            return ResponseEntity.status(HttpStatus.CREATED).body(createdAppointment);
        } catch (Exception ex) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null); // Return 500 Internal Server Error status
        }
    }


    // Get appointment by ID
    @GetMapping("/appointment/{id}")
    public ResponseEntity<Appointment> getAppointmentById(@PathVariable int id) {
        try {
            Appointment appointment = appointmentRepository.findById(id)
                    .orElseThrow(() -> new AttributeNotFoundException("Not found" + id));
            return ResponseEntity.ok(appointment);
        } catch (AttributeNotFoundException ex) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null); // Return 404 Not Found status
        }
    }

    // Edit appointment details
    @PutMapping("/appointment/{id}")
    public void editAppointment(@PathVariable("id") Integer id, @RequestBody Appointment appointment) {
        appointmentRepository.save(appointment);
    }

    // Delete appointment
    @DeleteMapping("/appointment/{id}")
    public ResponseEntity<Map<String, Boolean>> deleteAppointment(@PathVariable int id) {
        try {
            Appointment appointment = appointmentRepository.findById(id)
                    .orElseThrow(() -> new AttributeNotFoundException("Not found" + id));
            appointmentRepository.delete(appointment);
            Map<String, Boolean> response = new HashMap<>();
            response.put("deleted", Boolean.TRUE);
            return ResponseEntity.ok(response);
        } catch (AttributeNotFoundException ex) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null); // Return 404 Not Found status
        }
    }

    // Approve appointment
    @PutMapping("/appointment/{id}/approve")
    public ResponseEntity<Appointment> approveAppointment(@PathVariable("id") Integer id) {
        try {
            Appointment appointment = appointmentRepository.findById(id)
                    .orElseThrow(() -> new AttributeNotFoundException("Not found" + id));

            if ("Pending".equals(appointment.getStatus())) {
                appointment.setStatus("Approved");
                appointmentRepository.save(appointment);
                return ResponseEntity.ok(appointment);
            } else {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(appointment);
            }
        } catch (AttributeNotFoundException ex) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null); // Return 404 Not Found status
        }
    }

    
    // Reject appointment
    @PutMapping("/appointment/{id}/reject")
    public ResponseEntity<Appointment> rejectAppointment(@PathVariable("id") Integer id) {
        try {
            Appointment appointment = appointmentRepository.findById(id)
                    .orElseThrow(() -> new AttributeNotFoundException("Not found" + id));

            if ("Pending".equals(appointment.getStatus())) {
                appointment.setStatus("Rejected");
                appointmentRepository.save(appointment);
                return ResponseEntity.ok(appointment);
            } else {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(appointment);
            }
        } catch (AttributeNotFoundException ex) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null); // Return 404 Not Found status
        }
    }
}